criarCartao(
    "Categoria",    
    "Pergunta",  
    "Resposta" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

criarCartao(
    "Dinossauro",    
    "Qual o mlr dinossauro",  
    "todos" 
);

document.querySelectorAll('#container .cartao').forEach(cartao => {
    if (!cartao.innerHTML.trim()) {
        cartao.remove();
    }
});